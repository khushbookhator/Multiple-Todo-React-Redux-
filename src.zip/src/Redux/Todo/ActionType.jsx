export const GET_TODO_REQ = "GET_TODO_REQ"
export const GET_TODO_SUC = "GET_TODO_SUC"
export const GET_TODO_FAIL = "GET_TODO_FAIL"

export const ADD_TODO_REQ = "ADD_TODO_REQ"
export const ADD_TODO_SUC = "ADD_TODO_SUC"
export const ADD_TODO_FAIL = "ADD_TODO_FAIL"

export const TOGGLE_TODO_REQ = "TOGGLE_TODO_REQ"
export const TOGGLE_TODO_SUC = "TOGGLE_TODO_SUC"
export const TOGGLE_TODO_FAIL = "TOGGLE_TODO_FAIL"

export const DELETE_TODO_REQ = "DELETE_TODO_REQ"
export const DELETE_TODO_SUC = "DELETE_TODO_SUC"
export const DELETE_TODO_FAIL = "DELETE_TODO_FAIL"
